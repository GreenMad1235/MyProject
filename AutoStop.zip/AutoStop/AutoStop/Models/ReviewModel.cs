﻿using System.ComponentModel.DataAnnotations;

namespace AutoStop.Models
{
    public class ReviewModel
    {
        public string Id { get; set; }


        [Display(Name = "Маршрут")]
        public int RouteId { get; set; }
        public RouteModel RouteModel { get; set; }


        [MaxLength(200, ErrorMessage = "Максимальное количество символов 200")]
        [MinLength(50, ErrorMessage = "Минимальное количество символов 50")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Отзыв")]
        public string Review { get; set; }


        [Display(Name = "Дата публикации")]
        [DataType(DataType.Date)]
        public DateTime Publ { get; set; } = DateTime.Now;
        
    }
}
