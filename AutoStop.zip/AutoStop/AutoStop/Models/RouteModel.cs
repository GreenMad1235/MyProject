﻿using System.ComponentModel.DataAnnotations;

namespace AutoStop.Models
{
    public class RouteModel
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(50)]
        [Required(ErrorMessage = "Введите название маршрута")]
        [Display(Name = "Название маршрута")]
        public string RouteName { get; set; }

        [Display(Name = "Время прибытия")]
        [Required(ErrorMessage = "Введите время прибытия")]
        public DateTime timeArrive { get; set; }

        [Display(Name = "Время отправления")]
        [Required(ErrorMessage = "Введите время отправления")]
        public DateTime timeSend { get; set; }

        public int CarId { get; set; }
        [Display(Name = "Автомобиль")]
        public CarModel CarModels { get; set; }   
        public ICollection <ReviewModel> ReviewModel { get; set; }    
        public ICollection<PointModel> PointModels { get; set; }
        
    }
}
