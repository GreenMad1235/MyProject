﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AutoStop.Models
{
    public class UserModel : IdentityUser
    {
        [NotMapped]
        [Display(Name = "Фото пользователя")]
        public byte? [] PhotoUser { get; set; }

        [MaxLength(15)]
        [Required(ErrorMessage = "Введите имя")]
        [Display(Name = "Имя")]
        public string Name { get; set; }

        [MaxLength(15)]
        [Required(ErrorMessage = "Введите фамилию")]
        [Display(Name = "Фамилия")]
        public string Surname { get; set; }

        [Display(Name = "День рождение")]
        [Required(ErrorMessage = "Введите день рождения")]
        [DataType(DataType.DateTime)]
        public DateTime BithDay { get; set; }

        [DataType(DataType.DateTime)]
        [Display(Name = "Дата регистрации")]
        public DateTime DateReg { get; set; } = DateTime.Now;


        public ICollection<CarModel> Cars { get; set; }

    }
}