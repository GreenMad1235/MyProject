﻿using System.ComponentModel.DataAnnotations;

namespace AutoStop.Models
{
    public class PointModel
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Название точки")]
        public string PointName { get; set; }

        [Display(Name = "Точка Х")]
        public int X { get; set; }

        [Display(Name = "Точка У")]
        public int Y { get; set; }

        public int RouteId { get; set; }
        public RouteModel RouteModel { get; set; }
    }
}