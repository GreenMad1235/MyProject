﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using AutoStop.Models;

namespace AutoStop.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { 
        }
        public DbSet<UserModel> AppUser { get; set; }
        public DbSet<CarModel> Cars { get; set; }
        public DbSet<RouteModel> Routes { get; set; }
        public DbSet<PointModel> Points { get; set; }
        public DbSet<ReviewModel> Reviews { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<CarModel>()
                .HasOne(d => d.Driver)
                .WithMany(c => c.Cars)
                .HasForeignKey(d => d.DriverId);

            builder.Entity<RouteModel>()
                .HasOne(c => c.CarModels)
                .WithMany(r => r.Route)
                .HasForeignKey(c => c.CarId);

            builder.Entity<PointModel>()
                .HasOne(r => r.RouteModel)
                .WithMany(p => p.PointModels)
                .HasForeignKey(r => r.RouteId);

            builder.Entity<ReviewModel>()
                .HasOne(r => r.RouteModel)
                .WithMany(r => r.ReviewModel)
                .HasForeignKey(r => r.RouteId);
                
               
        }
    }
}