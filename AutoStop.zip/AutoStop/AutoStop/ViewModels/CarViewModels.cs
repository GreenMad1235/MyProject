﻿using AutoStop.Models;
using System.ComponentModel.DataAnnotations;

namespace AutoStop.ViewModels
{
    public class CarViewModels
    {
        public int Id { get; set; } 
        [Display(Name = "Марка авто")]
        [Required(ErrorMessage = "Заполните поле марка")]
        [MaxLength(10)]
        public string Brand { get; set; }

        [Display(Name = "Фото авто")]
        //[Required(ErrorMessage = "Выбирите фото авто")]
        public IFormFile Photo { get; set; }


        [Display(Name = "Водитель")]
        public UserModel? Driver { get; set; }

        [Display(Name = "Номер авто")]
        [Required(ErrorMessage = "Заполните поле номер машины")]
        [MaxLength(10)]
        public string NumberCar { get; set; }

        [Display(Name = "Коло-во мест в авто")]
        //[MaxLength(2)]
        [Required(ErrorMessage = "Введите количетсво мест в авто")]
        public int Chair { get; set; }

        public ICollection<RouteModel> Route { get; set; }

        [Display(Name = "Описание")]
        [DataType(DataType.MultilineText)]
        [Required(ErrorMessage = "Заполните поле описание")]
        [MinLength(100, ErrorMessage = "Описание должно иметь более 100 символов")]
        [MaxLength(200, ErrorMessage = "Описание может иметь не более 200 символов")]
        public string Desc { get; set; }

        [Display(Name = "Дата добавления")]
        [Required(ErrorMessage = "Введите дату")]
        [DataType(DataType.DateTime)]
        public DateTime Date { get; set; } = DateTime.Now;
    }
}
