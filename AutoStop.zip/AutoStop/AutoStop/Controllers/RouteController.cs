﻿using Microsoft.AspNetCore.Mvc;
using AutoStop.Models;
using AutoStop.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AutoStop.Controllers
{
    public class RouteController : Controller
    {
        private readonly ApplicationDbContext context;

        public RouteController(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        [HttpGet]
        public async Task<IActionResult> ListRoute(string sortOrder, string searchString, int ?pageNumber)
        {
            ViewData["DateSort"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["SearchString"] = searchString;

            var rout = from r in context.Routes
                      select r;

            if (!String.IsNullOrEmpty(searchString))
            {
                rout = rout.Where(r => r.RouteName.Contains(searchString)
                                       || r.CarModels.Brand.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "Date":
                    rout = rout.OrderBy(r => r.timeArrive);
                    break;
                case "date_desc":
                    rout = rout.OrderByDescending(r => r.timeArrive);
                    break;
            }

            int pageSize = 5;
            return View(await PaginatedList<RouteModel>.CreateAsync(rout.AsNoTracking().Include(c => c.CarModels), pageNumber ?? 1, pageSize));
        }

        [HttpPost]
        public IActionResult ListRoute(RouteModel route)
        {

            return View();
        }

        [HttpGet]
        public IActionResult AddRoute()
        {
            var car = from c in context.Cars
                      orderby c.Brand
                      select c; 
            ViewBag.Car = new SelectList(car, "Id", "Brand");
            return View();
        }

        [HttpPost]
        public IActionResult AddRoute(RouteModel route) 
        {
            context.Routes.Add(route);
            context.SaveChanges();
            return RedirectToAction("ListRoute");  
        }

        [HttpGet]
        public IActionResult DeleteRoute()
        {
            return View();
        }

        [HttpPost]
        public IActionResult DeleteRoute(int id ,RouteModel route)
        {
            return View();
        }

        [HttpGet]
        public IActionResult EditRoute()
        {
            return View();
        }

        [HttpPost]
        public IActionResult EditRoute(int id, RouteModel route)
        {
            return View();
        }
    }
}
