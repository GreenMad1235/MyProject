﻿using AutoStop.Data;
using AutoStop.Models;
using AutoStop.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoStop.Controllers
{
    public class CarController : Controller
    {
        private readonly ApplicationDbContext context;
        private readonly IWebHostEnvironment webHostEnvironment;

        public CarController(ApplicationDbContext ctx, IWebHostEnvironment hostEnvironment)
        {
            context = ctx;
            webHostEnvironment = hostEnvironment;
        }

        [HttpGet]
        public async Task<IActionResult> ListCar(string sortOrder, string searchString, int? pageNumber)
        {
            ViewData["DateSort"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["SearchString"] = searchString;

            var car = from c in context.Cars
                      select c;

            if (!String.IsNullOrEmpty(searchString))
            {
                car = car.Where(c => c.Brand.Contains(searchString)
                                       || c.Desc.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "Date":
                    car = car.OrderBy(c => c.Date);
                    break;
                case "date_desc":
                    car = car.OrderByDescending(c => c.Date);
                    break;
            }

            int pageSize = 5;
            return View(await PaginatedList<CarModel>.CreateAsync(car.AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        [HttpPost]
        public IActionResult ListCar(CarModel car)
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddCar()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddCar(CarViewModels carModel)
        {
            string uniqueFileName = UploadFile(carModel);
            CarModel car = new CarModel
            {
                Chair = carModel.Chair,
                NumberCar = carModel.NumberCar,
                Brand = carModel.Brand,
                Desc = carModel.Desc,
                Driver = carModel.Driver,
                Date = carModel.Date,
                PhotoCar = uniqueFileName,
            };
            context.Cars.Add(car);
            await context.SaveChangesAsync();
            return RedirectToAction("ListCar");


        }

        private string UploadFile(CarViewModels carModel)
        {
            string? uniqueFileName = null;
    
            if (carModel.Photo != null)
            {
                string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "images");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + carModel.Photo.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileSream = new FileStream(filePath, FileMode.Create))
                {
                    carModel.Photo.CopyTo(fileSream);
                }
            }

            return uniqueFileName;
        }

        [HttpGet]
        public IActionResult DeleteCar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult DeleteCar(CarModel car)
        {
            return View();
        }

        [HttpGet]
        public IActionResult EditCar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult EditCar(CarModel car)
        {
            return View();
        }

    }
}
