
    </div>
  </div>
</section>
<?php $tmpl = ob_get_clean(); ?>
<?php  echo $tmpl; ?>