<style>
.u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 72px;
  margin: 0 auto;
}
.u-header .u-image-1 {
  margin: 18px auto 0 0;
}
.u-header .u-logo-image-1 {
  max-width: 63px;
  max-height: 63px;
}
.u-header .u-social-icons-1 {
  white-space: nowrap;
  height: 26px;
  min-height: 16px;
  width: 98px;
  min-width: 68px;
  margin: -29px 0 0 auto;
}
.u-header .u-icon-1 {
  color: rgb(59, 89, 152) !important;
}
.u-header .u-icon-2 {
  color: rgb(85, 172, 238) !important;
}
.u-header .u-icon-3 {
  color: rgb(197, 54, 164) !important;
}
.u-header .u-menu-1 {
  margin: -31px 118px 16px auto;
}
.u-header .u-nav-1 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: uppercase;
}
.u-block-3a4c-25 {
  font-size: 1rem;
}
.u-header .u-nav-2 {
  font-size: 1rem;
}
.u-block-3a4c-26 {
  font-size: 1rem;
}
@media (max-width: 1199px) {
  .u-header .u-image-1 {
    width: 63px;
    height: 32px;
  }
  .u-header .u-menu-1 {
    margin-right: auto;
  }
}
@media (max-width: 767px) {
  .u-header .u-sheet-1 {
    min-height: 148px;
  }
  .u-header .u-image-1 {
    margin-top: 9px;
    margin-left: auto;
  }
  .u-header .u-social-icons-1 {
    margin-top: 20px;
    margin-right: auto;
  }
  .u-header .u-menu-1 {
    margin-top: 20px;
    margin-bottom: 9px;
  }
}
@media (max-width: 575px) {
  .u-header .u-sheet-1 {
    min-height: 165px;
  }
  .u-header .u-image-1 {
    margin-top: 18px;
  }
  .u-header .u-menu-1 {
    margin-bottom: 18px;
  }
}
</style>
<style>
.u-footer .u-sheet-1 {
  min-height: 120px;
}
.u-footer .u-social-icons-1 {
  height: 32px;
  min-height: 16px;
  width: 158px;
  min-width: 94px;
  white-space: nowrap;
  margin: 44px auto;
}
.u-footer .u-icon-1 {
  color: rgb(59, 89, 152) !important;
}
.u-footer .u-icon-2 {
  color: rgb(85, 172, 238) !important;
}
.u-footer .u-icon-3 {
  color: rgb(197, 54, 164) !important;
}
.u-footer .u-icon-4 {
  color: rgb(0, 122, 185) !important;
}
@media (max-width: 1199px) {
  .u-footer .u-sheet-1 {
    min-height: 99px;
  }
}
@media (max-width: 991px) {
  .u-footer .u-sheet-1 {
    min-height: 76px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-sheet-1 {
    min-height: 57px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-sheet-1 {
    min-height: 36px;
  }
}
</style>